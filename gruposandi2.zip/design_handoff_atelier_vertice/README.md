# Handoff: Atelier Vértice — Landing Page

## Overview
Landing page de marketing de una sola página para un estudio de arquitectura ficticio ("Atelier Vértice"). Comunica posicionamiento de marca, muestra portafolio, lista premios y captura leads cualificados vía formulario de briefing. Estética editorial oscura con tipografía serif de display.

## About the Design Files
Los archivos en `source/` son **referencias de diseño creadas como prototipo en HTML** — un mockup interactivo que muestra el look & feel y el comportamiento previstos. **No son código de producción**. La tarea es **recrear estos diseños en el entorno existente del codebase destino** (React + Vite, Next.js, Astro, Nuxt, SvelteKit, etc.) usando sus convenciones, design system y librerías. Si no existe un entorno, elige el framework más apropiado (recomendado: **Next.js 14+ con App Router** o **Astro** para una landing estática).

## Fidelity
**Alta fidelidad (hifi).** Colores, tipografía, espaciados, transiciones y micro-interacciones son finales. Implementar pixel-perfect, replicando los valores exactos que se documentan abajo.

## Stack sugerido
- **Next.js 14 (App Router)** o **Astro 4** para SSG / SSR.
- **Tailwind CSS** o **CSS Modules** (los tokens del diseño se mapean limpiamente a `tailwind.config.ts`).
- **Framer Motion** (opcional) para las revelaciones on-scroll y el carrusel del hero.
- **Imágenes**: `next/image` con `priority` en las imágenes del hero; usar formato AVIF/WebP.
- Fuentes: `next/font/google` con `Cormorant Garamond` (300, 400, 500 + 300 italic) y `JetBrains Mono` (400, 500). Para sans usar la pila system: `"Helvetica Neue", Helvetica, Arial, sans-serif`.

---

## Screens / Views

Es una **página única** con secciones ancladas. Header sticky, navegación scrollspy.

### 1. Header (fijo, top)
- **Layout**: `position: fixed`, full-width, padding `22px 40px` (desktop) / `18px 22px` (mobile). Tres columnas: brand · nav · CTA.
- **Estado inicial**: fondo transparente sobre el hero.
- **Estado `scrolled`** (>60px scroll): fondo `rgba(21,20,15,0.78)` + `backdrop-filter: blur(14px)` + borde inferior `1px solid #2a2720`.
- **Brand**: cuadrado outline 22×22px con texto `AV` (mono 11px) + label `Atelier Vértice` (serif 22px).
- **Nav**: 5 enlaces (Proyectos · Estudio · Premios · Diario · Contacto). Mono 11px, letter-spacing `0.18em`, uppercase, color `#9a948a`. Hover → `#ede8dc`. Activo → `#ede8dc` con subrayado `#b8966a` 1px.
- **CTA "Briefing 2026"**: pill 1px outline, dot pulsante `#b8966a` (animación 2.2s keyframe).
- **Responsive**: nav oculto < 980px (no se muestra menú hamburguesa en el mock — añadir uno usando el patrón del codebase).

### 2. Hero (full viewport)
- **Layout**: `height: 100vh; min-height: 720px`. Grid de 3 filas: top-bar · contenido-principal · bottom-bar. Padding `110px 40px 40px`.
- **Background**: carrusel de 4 slides (auto-rotate 6.5s). Cada slide es una imagen full-bleed con animación ken-burns (scale 1.04 → 1.12 en 8s). Overlay con dos gradientes:
  - Vertical: `rgba(21,20,15,0.55) 0% → 0.15 30% → 0.15 60% → 0.85 100%`
  - Horizontal: `rgba(21,20,15,0.55) 0% → 0 50%`
- **Grid overlay decorativo**: líneas verticales `rgba(237,232,220,0.04)` cada 25% del ancho.
- **Side label**: vertical-rl en el borde derecho, mono 10px, color `#9a948a`. Texto: "Scroll · Descubrir" — separador 80px — "Atelier · MMXXVI".
- **Top bar**: crumbs ("Featured · Obra reciente") a la izquierda + status del slide actual a la derecha. Mono 11px.
- **Contenido principal** (alineado al bottom):
  - Eyebrow color `#b8966a` con barra 32×1px: `{Tipología} · {Año}`
  - Título: serif 300, `clamp(64px, 9vw, 168px)`, line-height 0.92, letter-spacing −0.02em. La segunda palabra va en `<em>` itálica color `#b8966a`.
  - Meta lista horizontal (3 columnas: Ubicación / Superficie / Tipología). Etiqueta mono 11px + valor serif 22px. Border-top 1px sobre `#2a2720`.
- **Bottom bar**:
  - **Pager**: número actual serif 48px + track 180×1px con fill `#ede8dc` + total serif 18px color dim.
  - **Controles**: dos botones circulares 52×52 con borde `#4a463e`, flechas SVG stroke 1.4.

#### Datos del hero (4 slides)
```ts
[
  { name: "Casa Mirador",       location: "Valle de Bravo · México",   typology: "Residencial", year: "2025", area: "420 m²",     status: "Recién entregado" },
  { name: "Pabellón Ocoyoacac", location: "Estado de México",          typology: "Cultural",    year: "2024", area: "860 m²",     status: "En curaduría" },
  { name: "Casa Aguamiel",      location: "San Miguel de Allende",     typology: "Residencial", year: "2024", area: "510 m²",     status: "En construcción" },
  { name: "Torre Liminal",      location: "Polanco · CDMX",            typology: "Comercial",   year: "2026", area: "12 400 m²",  status: "En diseño" },
]
```

### 3. Marquee (banda divisoria)
- **Layout**: full-width, padding `22px 0`, background `#1c1a14`, borde top/bottom `#2a2720`.
- **Contenido**: 6 frases en serif italic 22px color `#9a948a`, separadas por dot `#b8966a` 6×6px. Animación CSS `translateX(-50%)` en 38s linear infinite. **Duplicar el array** para loop sin saltos.
- **Frases**: "Arquitectura habitada · Materia · Luz · Tiempo · Desde 2008 · México · Iberoamérica · Diseño con consciencia · Atelier Vértice".

### 4. Proyectos (`#work`)
- **Layout**: padding `140px 40px`. Section-head en grid 2 col con título serif a la izquierda + lead a la derecha (alineados al baseline inferior).
- **Filtros**: pill buttons mono 10px uppercase. Estado activo: bg `#ede8dc`, color `#15140f`. Cada pill incluye contador `[N]` con opacidad 0.5.
- **Categorías**: Todos · Residencial · Cultural · Comercial · Hospitalidad · Interiorismo.
- **Grid**: 12 columnas, gap 24px. Spans asimétricos por proyecto. Cada card tiene aspect ratio variable (`--ar`).
- **Card**:
  - Thumb con `background-image` y overlay gradient bottom 50%→`rgba(21,20,15,0.7)` que aparece en hover (opacity 0→1).
  - Imagen interna hace `scale(1.06)` en hover, transición 1.2s `cubic-bezier(0.2, 0.7, 0.2, 1)`.
  - Tag chip top-left: pill `rgba(21,20,15,0.7)` + blur 8px + border `rgba(237,232,220,0.12)`, mono 9px uppercase.
  - Arrow chip bottom-right: círculo 44×44 `#ede8dc` sobre `#15140f`, aparece en hover con translateY 8→0.
  - Meta debajo de thumb: nombre serif 26px + sub-mono dim + año mono 11px alineado a la derecha.

#### Spans (12-col grid)
| Proyecto              | Span    | Aspect Ratio |
|-----------------------|---------|--------------|
| Casa Horizonte        | span 7  | 62%          |
| Refugio Pinar         | span 5  | 62%          |
| Estudio Cantera       | span 4  | 82%          |
| Pabellón del Agua     | span 4  | 82%          |
| Casa Volcán           | span 4  | 82%          |
| Foro Brutalista       | span 8  | 55%          |
| Estancia Bardo        | span 4  | 110%         |
| Casa Ribera           | span 6  | 70%          |
| Loft Industria        | span 6  | 70%          |

### 5. Filosofía (`#studio`)
- **Background**: `#1c1a14`, border top/bottom `#2a2720`.
- **Section-head**: misma estructura que proyectos.
- **Quote principal**: serif 300, `clamp(32px, 4vw, 56px)`. La palabra "desocupar" en italic color `#b8966a`.
- **Pilares**: grid 2×2 con 4 bloques. Cada bloque tiene border-top, h4 serif 24px y p dim line-height 1.6.
  - Materia · Luz · Programa · Paisaje.
- **Stats**: grid 4 columnas, margin-top 80px, padding-top 60px, border-top. Cada stat: número serif 72px (algunos en italic `#b8966a`) + label dim debajo.
  - 17 años · *92* proyectos · 11 países · *24* premios.

### 6. Premios (`#awards`)
- **Section-head** estándar.
- **Lista**: rows en grid `80px 1fr 1fr 120px`. Cada row tiene border-bottom 1px.
- **Hover**: padding-left/right 24px + bg `rgba(184,150,106,0.04)`, transición 0.4s.
- **Columnas**: año (mono dim) · nombre (serif 28px) · premio (dim) · ubicación (mono dim uppercase, text-align right).
- **5 entradas** (ver `source/app.jsx` `AWARDS`).

### 7. Contacto (`#contact`)
- **Background**: `#1c1a14`.
- **Grid**: 2 columnas (1.2fr · 1fr), gap 80px.
- **Izquierda**: título grande (h2 serif) + info-list con 4 filas (Estudio · Correo · Teléfono · Horario). Etiqueta mono dim 140px / valor serif 24px, separadas por borders top.
- **Derecha (formulario)**:
  - Campos sin caja: solo label mono uppercase arriba + input serif 22px + border-bottom 1px. Sin border-top, sin background.
  - Layout: fila de 2 col (Nombre / Correo), luego full-width (Tipo de proyecto), luego pills de presupuesto (5 opciones), luego textarea, luego submit.
  - Pills de presupuesto: misma estética que filtros, pero activo usa `#b8966a` con texto `#15140f`.
  - Submit: pill `#ede8dc` con texto `#15140f`, mono 11px uppercase. Hover → bg `#b8966a`. Click → estado "Enviado · gracias" durante 3.2s, después reset.

### 8. Footer (`#journal`)
- **Background**: `#15140f`, border-top.
- **Grid**: 4 columnas (2fr · 1fr · 1fr · 1fr), gap 60px.
- **Columna brand**: "Atelier / Vértice" en serif 300 88px, italic + acento en "Vértice". Párrafo dim debajo. 4 redes sociales (IG · LinkedIn · Pinterest · Behance) como círculos 42×42 outline; hover → border y color `#b8966a` + translateY −2px.
- **3 columnas de links**: heading mono uppercase dim + lista con gap 14px. Hover → color `#b8966a` + padding-left 4px.
- **Bottom bar**: copyright + 3 links legales. Mono 10px uppercase dim.

---

## Interactions & Behavior

### Header
- Listener de scroll → toggle `.scrolled` class al pasar 60px.
- Scrollspy con `IntersectionObserver` o cálculo manual: detecta sección visible al 35% del viewport y actualiza link activo.
- Click en link → `scrollIntoView({ behavior: 'smooth' })`.

### Hero carrusel
- `setInterval` cada 6500ms avanza el slide.
- Controles prev/next reinician (o no — comportamiento actual: NO reinician el timer; mejorarlo opcionalmente).
- Transición de slide: `opacity` 1.2s.
- Imagen activa: animación `transform: scale(1.04 → 1.12)` durante 8s linear. Se reinicia con cada cambio.
- El número del pager se rellena con `String(idx + 1).padStart(2, "0")`.

### Filtros de proyectos
- `useMemo` filtra `PROJECTS` por categoría seleccionada. Reordenar/animar con `layoutId` de Framer Motion si se desea.

### Reveal on scroll
- Todos los elementos con clase `.reveal` empiezan en `opacity: 0; translateY(20px)`.
- `IntersectionObserver` con threshold 0.12 añade `.in` al entrar, transición `0.9s cubic-bezier(0.2, 0.7, 0.2, 1)`. Unobserve después de la primera vez.
- Stagger en cards: `transitionDelay: ${(i % 4) * 60}ms`.

### Formulario
- React state local. Validación mínima: name + email no vacíos.
- Submit → `setSent(true)`, mostrar "Enviado · gracias" 3.2s, después reset.
- En producción: conectar a endpoint (Resend, Formspree, Sanity, etc.).

### Marquee
- Animación CSS pura `@keyframes scroll { to { transform: translateX(-50%) } }` con duración 38s.
- **Importante**: el array de items se duplica en JSX (`[...items, ...items]`) para que el loop sea continuo.

---

## State Management
Todo es estado local de componente (`useState`). No requiere store global.

| Variable | Donde | Para qué |
|---|---|---|
| `scrolled` | Header | Cambiar fondo cuando hay scroll |
| `active` | App / Header | Link activo de la nav (scrollspy) |
| `idx` | Hero | Slide actual del carrusel |
| `filter` | Projects | Categoría seleccionada |
| `budget` | Contact | Pill de presupuesto activa |
| `form`, `sent` | Contact | Datos + estado del formulario |

---

## Design Tokens

### Colors
```css
--bg:         #15140f;   /* fondo carbón cálido            */
--bg-2:       #1c1a14;   /* fondo alterno (filosofía / marquee / contacto) */
--bg-3:       #24211a;   /* tercer nivel (no usado mucho)  */
--ink:        #ede8dc;   /* texto principal crema          */
--ink-dim:    #9a948a;   /* texto secundario               */
--ink-faint:  #4a463e;   /* bordes outline, placeholders   */
--accent:     #b8966a;   /* arena — italics & subrayados   */
--rule:       #2a2720;   /* divisores horizontales         */
```

### Typography
```css
--serif: "Cormorant Garamond", "Times New Roman", serif;
--sans:  "Helvetica Neue", Helvetica, Arial, sans-serif;
--mono:  "JetBrains Mono", ui-monospace, monospace;
```

Escala (en px, no rem para que sea fácil mapear):
| Uso | Fuente | Peso | Tamaño | Tracking |
|---|---|---|---|---|
| Hero title | serif | 300 | clamp(64, 9vw, 168) | −0.02em |
| Section h2 | serif | 300 | clamp(40, 5.5vw, 88) | −0.015em |
| Brand large (footer) | serif | 300 | 88 | −0.02em |
| Stat number | serif | 300 | 72 | −0.02em |
| Quote | serif | 300 | clamp(32, 4vw, 56) | −0.015em |
| Card name | serif | 400 | 26 | −0.005em |
| Awards name | serif | 400 | 28 | — |
| Hero meta value | serif | 400 | 22 | — |
| Form input | serif | 400 | 22 | — |
| Lead paragraph | serif | 400 | 22 | line-height 1.45 |
| Body | sans | 400 | 14 | line-height 1.55 |
| Mono labels | mono | 400 | 11 | 0.08–0.18em uppercase |
| Card tag | mono | 400 | 9 | 0.18em uppercase |

### Spacing
- Section vertical: `140px` desktop / `90px` mobile.
- Section horizontal: `40px` desktop / `22px` mobile.
- Grid gap: `24px` desktop / `18px` mobile.
- Footer grid gap: `60px`.

### Border radius
- Pills (CTAs, filtros, chips, redes sociales): `999px`.
- Cards: `0` (sin redondeo — estética arquitectónica).

### Shadows
- Sin sombras pesadas. Solo el pulse animado del dot del CTA: `box-shadow: 0 0 0 0–6px rgba(184,150,106, 0.55→0)`.

### Transiciones canon
- Hover suave en chrome: `0.2–0.25s ease`.
- Card image zoom: `1.2s cubic-bezier(0.2, 0.7, 0.2, 1)`.
- Hero slide opacity: `1.2s ease`.
- Ken-burns: `8s linear`.
- Reveal on scroll: `0.9s cubic-bezier(0.2, 0.7, 0.2, 1)`.
- Award row hover: `0.4s ease`.

### Film grain
SVG inline (turbulence fractalNoise) en overlay fijo, `opacity: 0.04`, `mix-blend-mode: overlay`. Ver `styles.css` clase `.grain`.

---

## Assets

### Imágenes (Unsplash — placeholders)
Las URLs en `source/app.jsx` son hotlinks a Unsplash. **Reemplazar antes de producción** por fotografía real licenciada del estudio. Las dimensiones recomendadas:
- Hero: 2400×1600 (3:2 horizontal), formato AVIF/WebP, < 220 KB cada una.
- Grid cards: 1600×1200 o variantes según `--ar` indicado.

### Iconografía
SVGs inline en `source/app.jsx`:
- `Arrow` — flecha 24×24 stroke 1.4 (usada en CTA, controles del hero, submit, hover de cards).
- `Plus` — cruz 24×24 stroke 1.4 (no usada actualmente — disponible).
- `IG / LI / Pin / Be` — redes sociales 24×24 filled.

No se usan librerías de iconos. Mantenerlo así o migrar a `lucide-react` si el codebase ya lo tiene.

### Fuentes
Cargadas vía Google Fonts en `index.html`:
```html
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;1,300&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet" />
```
En Next.js, migrar a `next/font/google` para evitar layout shift.

---

## Responsive
Un solo breakpoint principal: `@media (max-width: 980px)`. Cambios principales:
- Nav oculta (implementar menú móvil — no está en el mock).
- Section padding reduce a `90px 22px`.
- Section-head pasa a una sola columna.
- Grid de proyectos pasa a 6 col, todos los spans → `span 6`.
- Stats pasa de 4 → 2 col.
- Hero side label oculto.
- Pager track reduce a 100px.

---

## Files
```
source/
├── index.html      Entry point + carga de fuentes y bundles
├── styles.css      Todos los estilos (tokens, layout, animaciones)
└── app.jsx         React 18 — componentes, datos, lógica de carrusel/filtros/form
```

Es React 18 + Babel standalone (in-browser transpile). En producción: convertir a JSX precompilado en el framework destino, separar en componentes (`Header.tsx`, `Hero.tsx`, `Projects.tsx`, etc.) y mover datos a una capa de contenido (CMS, MDX, JSON).

---

## Checklist de implementación
- [ ] Configurar fuentes (Cormorant Garamond + JetBrains Mono)
- [ ] Definir design tokens en config del framework (Tailwind theme / CSS vars)
- [ ] Header sticky + scrollspy + smooth scroll
- [ ] Hero carrusel con auto-rotate + controles + ken-burns
- [ ] Marquee CSS infinite loop
- [ ] Grid de proyectos asimétrico + filtros
- [ ] Reveal on scroll (IntersectionObserver o Framer Motion)
- [ ] Sección filosofía con stats
- [ ] Lista de premios con hover expansivo
- [ ] Formulario de contacto + integración con backend
- [ ] Footer con redes
- [ ] Responsive < 980px (incluir menú móvil)
- [ ] Reemplazar imágenes Unsplash por fotografía real
- [ ] SEO: meta tags, OG image, schema.org/Organization
- [ ] Lighthouse: > 95 en todas las categorías
